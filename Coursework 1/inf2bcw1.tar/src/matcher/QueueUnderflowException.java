package matcher;

@SuppressWarnings("serial")
public class QueueUnderflowException extends Exception {
}